//
//  APIConnection.h
//  NextBus8
//
//  Created by Mike K on 11/1/14.
//  Copyright (c) 2014 com.mkomadina. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface APIConnection : NSObject

- (NSString*) getDeparturesURLforStopCode: (NSString *) stopCode;  // get URL for returing bus departures

@end
