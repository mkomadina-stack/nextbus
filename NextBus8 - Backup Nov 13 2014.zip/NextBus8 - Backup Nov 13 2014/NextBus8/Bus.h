//
//  Bus.h
//  NextBus8
//
//  Created by Mike K on 11/1/14.
//  Copyright (c) 2014 com.mkomadina. All rights reserved.
//
//  The main class for storing departure information for buses


#import <Foundation/Foundation.h>

@interface Bus : NSObject

@property NSString *departMinutesXML;  // departure time in minutes such as "15"
@property NSString *agencyXML;      // name of agency such as "SamTrans"
@property NSString *routeCodeXML;   // route code such as "274"
@property NSString *directionXML;   // direction such as "WEST"
@property NSString *stopNameXML;    // stop name such as "Canada College"
@property NSString *stopCodeXML;    // SamTrans internal id for a stop such as "321001"

@property long busGroupNumber;    // groups buses together who have same route and direction

@property BOOL selectedBus;         // TRUE if bus is chosen


// set bus departure information 
-(id) initWithTime: (NSString *) inDepartTime
         forAgency: (NSString *) inAgency
      andRouteCode: (NSString *) inRouteCode
      andDirection: (NSString *) inDirection
       andStopName: (NSString *) inStopName
       andStopCode: (NSString *) inStopCode
        andGroupNumber:(long) groupNumber
       andSelected:(BOOL) selectedBus;

// accessors to get departure time in minutes or date/time
-(long) departureMinutes;
-(NSDate *) departureTime;

@end
