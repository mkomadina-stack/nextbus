//
//  APIConnection.m
//  NextBus8
//
//  Created by Mike K on 11/1/14.
//  Copyright (c) 2014 com.mkomadina. All rights reserved.
//

#import "APIConnection.h"

@implementation APIConnection

const NSString *TOKEN = @"1c61def7-8b50-48d9-a363-8c327ca158e1";    // Developer token from SamTrans
const NSString *DEPARTURE_API = @"http://services.my511.org/Transit2.0/GetNextDeparturesByStopCode.aspx";
const NSString *DEPARTURE_ARGS = @"&stopcode=";

- (NSString*) getDeparturesURLforStopCode: (NSString *) stopCode
{
    // accepts a valid bus stop code
    // returns a string for the API URL to be used to make an API connection
    
    // departure API includes the token and stopcode
    
    NSString *apiURL = [NSString stringWithFormat:@"%@?token=%@%@%@",
                        DEPARTURE_API,
                        TOKEN,
                        DEPARTURE_ARGS,
                        stopCode];
    
    NSLog(@"API URL:  %@", apiURL);
    
    return apiURL;
}

@end
