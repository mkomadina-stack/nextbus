//
//  BusTableViewCell.h
//  NextBus8
//
//  Created by Mike K on 11/2/14.
//  Copyright (c) 2014 com.mkomadina. All rights reserved.
//
//  Helpful references:
//      http://www.raywenderlich.com/73602/dynamic-table-view-cell-height-auto-layout
//      http://www.colejoplin.com/2012/09/28/ios-tutorial-basics-of-table-views-and-prototype-cells-in-storyboards

#import <UIKit/UIKit.h>

@interface BusTableViewCell : UITableViewCell

    @property (nonatomic, weak) IBOutlet UILabel *minutesLeftLabel; // departure in minutes left
    @property (nonatomic, weak) IBOutlet UILabel *busNumberLabel;   // bus number and direction
    @property (nonatomic, weak) IBOutlet UILabel *timeLabel;        // estimated clock time
    @property (nonatomic, weak) IBOutlet UILabel *staticMinutesLabel;

    @property (nonatomic, weak) IBOutlet UIImageView *directionImage;       // used to show north, south, ...

    @property (nonatomic, weak) IBOutlet UILabel *departureTimeLabel;


@end
