//
//  BusStop.h
//  nextBusTestStops
//
//  Created by Mike K on 10/6/14.
//  Copyright (c) 2014 com.mkomadina. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BusStop : NSObject

@property NSString* name;
@property NSString* stopCode;
@property NSString* image;
@property NSString* agency;

@end
