//
//  RouteColor.h
//  NextBus8
//
//  Created by Mike K on 11/3/14.
//  Copyright (c) 2014 com.mkomadina. All rights reserved.
//
//  Used for creating distinct colors for routes

#import <Foundation/Foundation.h>

@interface RouteColor : NSObject

-(UIColor *) forGroup: (long) groupNumber;  // return a unique color for each group number

@end
