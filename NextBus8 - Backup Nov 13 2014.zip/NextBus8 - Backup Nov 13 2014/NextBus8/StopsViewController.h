//
//  ViewController.h
//  nextBusTestStops
//
//  Created by Mike K on 10/5/14.
//  Copyright (c) 2014 com.mkomadina. All rights reserved.
//
//  sources:  http://www.appcoda.com/search-bar-tutorial-ios7/

#import <UIKit/UIKit.h>

@interface StopsViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
@property (strong, nonatomic) NSArray *stopList;
@property (strong, nonatomic) NSArray *searchResults;

@property NSString *selectedStop;
@property NSString *stopImageName;


@end
