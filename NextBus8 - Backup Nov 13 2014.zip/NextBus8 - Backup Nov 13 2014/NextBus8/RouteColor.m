//
//  RouteColor.m
//  NextBus8
//
//  Created by Mike K on 11/3/14.
//  Copyright (c) 2014 com.mkomadina. All rights reserved.
//
//  Used for creating distinct colors for routes

#import "RouteColor.h"

@implementation RouteColor

NSArray *colorArray;

- (id)init {
    
    // init the parent
    self = [super init];
    
    if (self) {
        
        
        colorArray = [[NSArray alloc ] initWithObjects:
                      
        [UIColor cyanColor],
        [UIColor yellowColor],
        [UIColor greenColor],
                      [UIColor cyanColor],
                      [UIColor yellowColor],
                      [UIColor greenColor],
        [UIColor cyanColor],
                      [UIColor yellowColor],
                      [UIColor greenColor],       [UIColor cyanColor],
                      [UIColor yellowColor],
                      [UIColor greenColor],       [UIColor cyanColor],
                      [UIColor yellowColor],
                      [UIColor greenColor],        [UIColor cyanColor],
                      [UIColor yellowColor],
                      [UIColor greenColor],        [UIColor cyanColor],
                      [UIColor yellowColor],
                      [UIColor greenColor],       [UIColor cyanColor],
                      [UIColor yellowColor],
                      [UIColor greenColor],
  
                      
                               nil];
        
        
         
        //[UIColor colorWithRed:0.0f green:200.0f blue:255.0f alpha:1.0f],
                      
                      
        
        
        
        
    
    }

    return self;
}

-(UIColor *) forGroup: (long) groupNumber {
    
    long numColors = [colorArray count];
    
    
    // check if there is a group number to match
    // and return the color for that group
    
    if (groupNumber < numColors) {
        return [colorArray objectAtIndex:groupNumber];
    }
    else
    {
        return [UIColor whiteColor];    // white is default
    }
    
}


@end
