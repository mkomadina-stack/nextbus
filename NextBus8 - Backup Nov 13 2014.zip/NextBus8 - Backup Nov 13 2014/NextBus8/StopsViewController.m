//
//  ViewController.m
//  nextBusTestStops
//
//  Created by Mike K on 10/5/14.
//  Copyright (c) 2014 com.mkomadina. All rights reserved.
//
//  references:     http://www.appcoda.com/uitableview-tutorial-storyboard-xcode5/
//                  http://www.appcoda.com/ios-programming-index-list-uitableview/
//                  http://www.appcoda.com/how-to-handle-row-selection-in-uitableview/
//                  http://stackoverflow.com/questions/12561735/what-are-unwind-segues-for-and-how-do-you-use-them

#import "StopsViewController.h"
#import "BusStop.h"
#import "ViewController.h"
#import "StopListSingleton.h"
#import "DeparturesViewController.h"

@interface StopsViewController ()

@end

@implementation StopsViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    StopListSingleton *globalStopList = [StopListSingleton getInstance];
    _stopList = [globalStopList getList];
    
    // enable the cancel button
    [self enableCancelButton:self.searchDisplayController.searchBar];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        return [_searchResults count];
        
    } else {
        return [_stopList count];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"CustomTableCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    // Configure the cell...
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
    }
    
    // Display stoplist
    NSDictionary *stop = nil;
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        stop = [_searchResults objectAtIndex:indexPath.row];
    } else {
        stop = [_stopList objectAtIndex:indexPath.row];
    }
    
    cell.textLabel.text = stop[@"name"];
    
    return cell;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)filterContentForSearchText:(NSString*)searchText scope:(NSString*)scope
{
    NSPredicate *resultPredicate = [NSPredicate predicateWithFormat:@"name contains[c] %@", searchText];
    _searchResults = [_stopList filteredArrayUsingPredicate:resultPredicate];
}

-(BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString
{
    [self filterContentForSearchText:searchString
                               scope:[[self.searchDisplayController.searchBar scopeButtonTitles]
                                      objectAtIndex:[self.searchDisplayController.searchBar
                                                     selectedScopeButtonIndex]]];
    
    return YES;
}



- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    BusStop *b = [[BusStop alloc] init];
    
    NSDictionary *stop = nil;
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        stop = [_searchResults objectAtIndex:indexPath.row];
    } else {
        stop = [_stopList objectAtIndex:indexPath.row];
    }
    
    
    b.name = stop[@"name"];
    b.stopCode = stop[@"stopCode"];
    b.agency = stop[@"agency"];
    b.image = stop[@"image"];
    
    
    NSLog(@"%@: %@", b.name, b.stopCode);
    
    _selectedStop = b.stopCode; // select the stop
    _stopImageName = b.image; // save the stop image
    
    // prepare for unwinding to main screen
    
    [self performSegueWithIdentifier:@"SegueToMain" sender:self];
    
}

-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    DeparturesViewController *destination = [segue destinationViewController];
    
  /*  destination.activeStop = _selectedStop;
    destination.activeBackgroundImage = _stopImageName;
    destination.dataObject.stopCode = _selectedStop;
    destination.dataObject.image = _stopImageName; */
    
    /***** FIX ****/
    destination.busStopCode = _selectedStop;

 

    NSLog(@"in prepareForSeque");
    
}

- (void)searchBarCancelButtonClicked:(UISearchBar *) searchBar {
    [searchBar resignFirstResponder];
    [searchBar setShowsCancelButton:NO animated:YES];
    
    [self dismissViewControllerAnimated:true completion:nil];
    
    NSLog(@"in searchBarCancel");
}


- (void)enableCancelButton:(UISearchBar *)searchBar
{
    for (UIView *view in searchBar.subviews)
    {
        for (id subview in view.subviews)
        {
            if ( [subview isKindOfClass:[UIButton class]] )
            {
                [subview setEnabled:YES];
                NSLog(@"enableCancelButton");
                return;
            }
        }
    }
}

@end
