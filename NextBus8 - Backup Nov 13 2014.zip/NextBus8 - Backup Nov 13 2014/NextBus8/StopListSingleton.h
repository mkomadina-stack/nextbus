//
//  StopListSingleton.h
//  NextBus4
//
//  Created by Mike K on 10/10/14.
//  Copyright (c) 2014 com.mkomadina. All rights reserved.
//
//  Used for holding a global instance of the list of bus stops
//  helpful:  http://chrisrisner.com/31-Days-of-iOS--Day-10–Singletons-and-the-AppDelegate


#import <Foundation/Foundation.h>

@interface StopListSingleton : NSObject {

}

+(StopListSingleton*) getInstance;  // get instance of class
-(NSArray *) getList;               // get the list of bus stops

@end
