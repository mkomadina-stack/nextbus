//
//  BusTableViewCell.m
//  NextBus8
//
//  Created by Mike K on 11/2/14.
//  Copyright (c) 2014 com.mkomadina. All rights reserved.
//

#import "BusTableViewCell.h"

@implementation BusTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        
        //self.mainView.layer.cornerRadius = 10;
        //self.mainView.layer.masksToBounds = YES;
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
