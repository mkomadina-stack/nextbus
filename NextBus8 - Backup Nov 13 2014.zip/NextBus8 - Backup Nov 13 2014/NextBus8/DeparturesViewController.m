//
//  DeparturesViewController.m
//  NextBus8
//
//  Created by Mike K on 11/1/14.
//  Copyright (c) 2014 com.mkomadina. All rights reserved.
//
//  Helpful references:
//     http://codewithchris.com/tutorial-how-to-use-ios-nsurlconnection-by-example/
//      http://www.thinkandbuild.it/animating-uitableview-cells/
//      http://www.appcoda.com/pull-to-refresh-uitableview-empty/
//      http://stackoverflow.com/questions/10291537/pull-to-refresh-uitableview-without-uitableviewcontroller
//      https://coffeeshopped.com/2010/09/iphone-how-to-dynamically-color-a-uiimage

//

// Amazon web services used for now to host list of stops
//  http://aws.amazon.com/developers/getting-started/ios/
// Had to add libz to framework to make amazon work
// http://stackoverflow.com/questions/5593219/error-with-gzipinflate-gzipdeflate

#import "DeparturesViewController.h"
#import "APIConnection.h"
#import "DeparturesParser.h"
#import "Bus.h"
#import "BusTableViewCell.h"
#import "RouteColor.h"
#import "StopListSingleton.h"
#import "StopsViewController.h"

// Amazon Web Services framework to host remote stoplist files

#import <AWSiOSSDKv2/S3.h>
//#import <AWSiOSSDKv2/DynamoDB.h>
//#import <AWSiOSSDKv2/SQS.h>
//#import <AWSiOSSDKv2/SNS.h>




static NSString * const BusCellIdentifier = @"BusTableViewCell";  // for custom cell

@interface DeparturesViewController ()

@end

@implementation DeparturesViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}


- (void)viewDidLoad
{
    
    // setup the parent class as required
    [super viewDidLoad];
    
 
    // setup the tableview delegate and datasource
    departureTableView.delegate = self;
    departureTableView.dataSource = self;
    
    // set the row size for the table
    departureTableView.rowHeight = 100;
    departureTableView.separatorColor = [UIColor whiteColor];
    departureTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLineEtched;

    departureTableView.backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"background.png"]];
    
    // This will remove extra separators from tableview
    departureTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    
    // setup the current bus stop
    _busStopCode = @"321001";
    _busStopCode = @"13191";
    //_busStopCode = @"311052";
       _busStopCode = @"344637";
    
    // create an instance of route color for generating distinct colors for a route
    _routeColor = [[RouteColor alloc] init];
    
    // set the default sort order by departure time or group number
    //_sortBy = @"busGroupNumber";
    _sortBy = @"departureMinutes";

    
    
    // schedule a timer to run every minute to update the view
    [NSTimer scheduledTimerWithTimeInterval:60.0
                                     target:self
                                   selector:@selector(fetchDepartures)
                                   userInfo:nil
                                    repeats:YES];
    
    // Initialize the refresh control.
    
    UIRefreshControl *refreshControl = [[UIRefreshControl alloc] init];
    [refreshControl addTarget:self action:@selector(refresh:) forControlEvents:UIControlEventValueChanged];
    [departureTableView addSubview:refreshControl];
    
    // initiate the asynchronous API call to fetch the bus departures
    [self fetchDepartures];
    
}

- (void)refresh:(UIRefreshControl *)refreshControl {
    [refreshControl endRefreshing];
    [self fetchDepartures];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // if there are no buses, leave a row for status
    
    return [_busArray count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    return [self busCellAtIndexPath:indexPath tableView:tableView];
}

- (BusTableViewCell *)busCellAtIndexPath:(NSIndexPath *)indexPath tableView:(UITableView *) tableView {
    BusTableViewCell *cell = [departureTableView dequeueReusableCellWithIdentifier:BusCellIdentifier forIndexPath:indexPath];
    
    [self configureBusCell:cell atIndexPath:indexPath];
    return cell;    
}

- (void)configureBusCell:(BusTableViewCell *)cell atIndexPath:(NSIndexPath *)indexPath {
    
    Bus *b;
    UIColor *busColor, *directionColor;
    
    
    // set the cell background
    UIView *backView = [[UIView alloc] initWithFrame:CGRectZero];
    backView.backgroundColor = [UIColor darkGrayColor];
    backView.alpha  = 0.4f;
    cell.backgroundView = backView;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    // configure button tap
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(didTapOnDirectionImage)];
       [cell addGestureRecognizer:tap];
    
    
    // the table view will display the array of buses using the same index
    b = [_busArray objectAtIndex:indexPath.row];
    
    [self setDepartureMinutesForCell:cell text:b.departMinutesXML];
    [self setSubtitleForCell:cell forBus:b];
    
    // get the color for the bus if sorted by route,
    // otherwise use a default color
    if ([_sortBy isEqualToString:@"departureMinutes"]) {
        busColor = [UIColor whiteColor];
        directionColor = busColor;
        [cell.timeLabel setTextColor: [UIColor greenColor]];
        [cell.staticMinutesLabel setTextColor: [UIColor greenColor]];
    }
    else
    {
        busColor = [_routeColor forGroup:b.busGroupNumber];
        
        directionColor = busColor;
        [cell.timeLabel setTextColor: busColor];
        [cell.staticMinutesLabel setTextColor: busColor];
    }
    
   // [cell.timeLabel setTextColor: busColor];
    //[cell.staticMinutesLabel setTextColor: busColor];
    [cell.busNumberLabel setTextColor: busColor];
    [cell.departureTimeLabel setTextColor: busColor];
    
    

    // set the direction indicator for north, south, east, west, inbound...
    
    if ([b.directionXML isEqualToString:@"NORTH"])
    {
        cell.directionImage.image = [self imageNamed:@"compas.png" withColor:directionColor];
    }
    else if ([b.directionXML isEqualToString:@"SOUTH"])
    {
        cell.directionImage.image = [self imageNamed:@"compas.png" withColor:directionColor];
    }
    else if ([b.directionXML isEqualToString:@"EAST"])
    {
        cell.directionImage.image = [self imageNamed:@"compas.png" withColor:directionColor];
    }
    else if ([b.directionXML isEqualToString:@"WEST"])
    {
        cell.directionImage.image = [self imageNamed:@"compas.png" withColor:directionColor];
    }

    
    //hide the image for now
    cell.directionImage.hidden = TRUE;
}


/*- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"didSelectRowAtIndexPath");
    
    // get the item that was tapped
    long index = indexPath.row;
    Bus *b = [_busArray objectAtIndex:index];
    b.selectedBus = TRUE;
    
    
    [self didTapOnDirectionImage];  // FIX THE NAME BUT CONTINEU
} */

- (void) didTapOnDirectionImage {
    
    NSLog(@"didTapOnDirectionImage");
    
    // toggle the sort by
    if ([_sortBy isEqualToString:@"departureMinutes"])
    {
        _sortBy = @"busGroupNumber";
        
    }
    else if ([_sortBy isEqualToString:@"busGroupNumber"])
    {
        _sortBy = @"departureMinutes";
        
        // scroll to top when sorting by departure times
        departureTableView.contentOffset = CGPointMake(0, 0 - departureTableView.contentInset.top);
    }
    
    // re-sort
    NSSortDescriptor *busSorter = [[NSSortDescriptor alloc] initWithKey:_sortBy ascending:YES];
    [_busArray sortUsingDescriptors:[NSArray arrayWithObject:busSorter]];
    
    
    // scroll to top when sorting by departure times
    departureTableView.contentOffset = CGPointMake(0, 0 - departureTableView.contentInset.top);
    
    // refresh the table view
    [departureTableView reloadData];
    

    /*
    // re-sort
    NSSortDescriptor *busSorter = [[NSSortDescriptor alloc] initWithKey:_sortBy ascending:YES];
    [_busArray sortUsingDescriptors:[NSArray arrayWithObject:busSorter]];
    
    // refresh the table view
    [departureTableView reloadData];
    
    NSInteger count = [_busArray count];
    Bus *b;
    
    // refresh the table view
    [departureTableView reloadData];
    
    // scroll to the selected row
    for (int i = 0; i < count; i++)
    {
        b = [_busArray objectAtIndex:i];
        
        if (b.selectedBus == TRUE) {
            
            NSIndexPath *scrollIndexPath = [NSIndexPath indexPathForRow:i inSection:0];
        
            [departureTableView scrollToRowAtIndexPath:scrollIndexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
            
            b.selectedBus = FALSE; // reset
        }
    }
    
 */
    
 
}

- (void)setDepartureMinutesForCell:(BusTableViewCell *)cell text:(NSString *) text {

    // NSString *displayText = [NSString stringWithFormat:@"%@ Minutes", text];
    NSString *displayText = text;
    
    int timeInMinutes = [displayText intValue];
    
    
    // if less than 10 minutes, use green color to highlight
    if (timeInMinutes < 10)
    {
        [cell.timeLabel setTextColor:[UIColor orangeColor]];
        [cell.staticMinutesLabel setTextColor:[UIColor orangeColor]];
        [cell.busNumberLabel setTextColor:[UIColor orangeColor]];
        [cell.departureTimeLabel setTextColor:[UIColor orangeColor]];

        
        // prepend a space for formattting
        displayText = [NSString stringWithFormat:@" %@", displayText];
    
        
    }
    else if (timeInMinutes <= 20)
    {
        [cell.timeLabel setTextColor:[UIColor yellowColor]];
        [cell.staticMinutesLabel setTextColor:[UIColor yellowColor]];
        [cell.busNumberLabel setTextColor:[UIColor yellowColor]];
        [cell.departureTimeLabel setTextColor:[UIColor yellowColor]];

    }
    else
    {
        [cell.timeLabel setTextColor:[UIColor greenColor]];
        [cell.staticMinutesLabel setTextColor:[UIColor greenColor]];
       [cell.busNumberLabel setTextColor:[UIColor greenColor]];
        [cell.departureTimeLabel setTextColor:[UIColor greenColor]];
    }
    
    [cell.timeLabel setText:displayText];
    

}

- (void)setSubtitleForCell:(BusTableViewCell *)cell forBus:(Bus *) bus {
    
    // Some subtitles can be really long, so only display the
    // first 200 characters
   // if (subtitle.length > 200) {
   //     subtitle = [NSString stringWithFormat:@"%@...", [subtitle substringToIndex:200]];
   // }
   
    
    // display the bus number and route
    
    NSString *displayText = [NSString stringWithFormat:
                             @"%@ %@",
                            bus.routeCodeXML,
                            bus.directionXML];
    
    [cell.busNumberLabel setText:displayText];
    
    // format the date and time
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"h:mm a"];
    NSString *formattedDateString = [dateFormatter stringFromDate:bus.departureTime];
    
    displayText = [NSString stringWithFormat:
                           @"%@ departure",
                            formattedDateString];
    
    [cell.departureTimeLabel setText:displayText];

    
    
}


//This function is where all the magic happens
// shows a rotation in of the table
// adapted from source: http://www.thinkandbuild.it/animating-uitableview-cells/
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    //1. Setup the CATransform3D structure
    CATransform3D rotation;
    rotation = CATransform3DMakeRotation( (90.0*M_PI)/180, 0.0, 0.7, 0.4);
    rotation.m34 = 1.0/ -600;
    
    
    //2. Define the initial state (Before the animation)
    cell.layer.shadowColor = [[UIColor blackColor]CGColor];
    cell.layer.shadowOffset = CGSizeMake(10, 10);
    cell.alpha = 0;
    
    cell.layer.transform = rotation;
    cell.layer.anchorPoint = CGPointMake(0, 0.5);
    
    
    //3. Define the final state (After the animation) and commit the animation
    [UIView beginAnimations:@"rotation" context:NULL];
    [UIView setAnimationDuration:0.8];
    cell.layer.transform = CATransform3DIdentity;
    cell.alpha = 1;
    cell.layer.shadowOffset = CGSizeMake(0, 0);
    [UIView commitAnimations];
    
}

// https://coffeeshopped.com/2010/09/iphone-how-to-dynamically-color-a-uiimage
//
- (UIImage *)imageNamed:(NSString *)name withColor:(UIColor *)color {
    
    // load the image
    UIImage *img = [UIImage imageNamed:name];
    
    // begin a new image context, to draw our colored image onto
    UIGraphicsBeginImageContext(img.size);
    
    // get a reference to that context we created
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    // set the fill color
    [color setFill];
    
    // translate/flip the graphics context (for transforming from CG* coords to UI* coords
    CGContextTranslateCTM(context, 0, img.size.height);
    CGContextScaleCTM(context, 1.0, -1.0);
    
    // set the blend mode to color burn, and the original image
   // CGContextSetBlendMode(context, kCGBlendModeColorBurn);
    CGContextSetBlendMode(context, kCGBlendModeMultiply);
    CGRect rect = CGRectMake(0, 0, img.size.width, img.size.height);
    CGContextDrawImage(context, rect, img.CGImage);
    
    // set a mask that matches the shape of the image, then draw (color burn) a colored rectangle
    CGContextClipToMask(context, rect, img.CGImage);
    CGContextAddRect(context, rect);
    CGContextDrawPath(context,kCGPathFill);
    
    // generate a new UIImage from the graphics context we drew onto
    UIImage *coloredImg = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    //return the color-burned image
    return coloredImg;
}


-(IBAction) returned:(UIStoryboardSegue *) segue {
    //
    
    NSLog(@"In DeparturesViewController: returned");
    
    
    // save the array of the pages since a change was made
   // [_myParentPageController savePages];
    
    
    // get new departures
    [self fetchDepartures];
}



- (IBAction)buttonBusStops:(id)sender {
    
    // create an instance of the controller for the list of bus stops
    // and switch to the new view controller
    
   // StopsViewController *stopsView = [[StopsViewController alloc] initWithNibName:nil bundle:nil];
 //   [self presentViewController:stopsView animated:YES completion:NULL];
}

- (IBAction)directionButton:(id)sender {
    _sortBy = @"departureMinutes";
    
    [self sortBuses];
    
}

- (IBAction) minutesButton:(id)sender {
    _sortBy = @"busGroupNumber";
    
    [self sortBuses];

}

- (void) sortBuses {
    
    // re-sort
    NSSortDescriptor *busSorter = [[NSSortDescriptor alloc] initWithKey:_sortBy ascending:YES];
    [_busArray sortUsingDescriptors:[NSArray arrayWithObject:busSorter]];
    
    // refresh the table view
    [departureTableView reloadData];
}



-(void) fetchDepartures
{
    
    // Setup the API URL
    NSString *url = [self getAPIURL];
    
    // Create the request.
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    // Create url connection and fire request
    _connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
    
}

-(void) parseResponse {

    // create and run the parser
    _departureParser = [[DeparturesParser alloc] initWithData:_responseData];
    [_departureParser parseAPI];
    
    // set the display title
    stopLabel.text = _departureParser.currentStopName;
    
    // copy the array results to the view
    _busArray = [[NSMutableArray alloc] initWithArray:_departureParser.busArray];
               
}

- (NSString *) getAPIURL {
    
    // returns the URL for making the API connection
    
    APIConnection *api;
    NSString *URL;
    
    // get the URL for the API for departures
    
    api = [[APIConnection alloc]init];
    URL = [api getDeparturesURLforStopCode:_busStopCode];
    return URL;
}



#pragma mark NSURLConnection Delegate Methods

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    // A response has been received, this is where we initialize the instance var
    // so that we can append data to it in the didReceiveData method
    // Furthermore, this method is called each time there is a redirect so reinitializing it
    // also serves to clear it
    _responseData = [[NSMutableData alloc] init];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    // Append the new data to the instance variable
    [_responseData appendData:data];

}

- (NSCachedURLResponse *)connection:(NSURLConnection *)connection
                  willCacheResponse:(NSCachedURLResponse*)cachedResponse {
    // Return nil to indicate not necessary to store a cached response for this connection
    return nil;
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    // The request is complete and data has been received
    // You can parse the stuff in your instance variable now
    
    NSLog(@"DeparturesViewController: connectionDidFinishLoading");
    
    
    // parse the XML data from the API
    [self parseResponse];
    
    // sort the bus array using _sortBy to specify sorting field
    
    NSSortDescriptor *busSorter = [[NSSortDescriptor alloc] initWithKey:_sortBy ascending:YES];
    [_busArray sortUsingDescriptors:[NSArray arrayWithObject:busSorter]];
    
    // refresh the table view
    [departureTableView reloadData];
    
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    // The request has failed for some reason!
    // Check the error var
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/




@end
