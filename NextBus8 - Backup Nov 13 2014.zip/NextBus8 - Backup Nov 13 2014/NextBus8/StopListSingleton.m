//
//  StopListSingleton.m
//  NextBus4
//
//  Created by Mike K on 10/10/14.
//  Copyright (c) 2014 com.mkomadina. All rights reserved.
//
//  Used for holding a global instance of the list of bus stops
//  helpful:  http://chrisrisner.com/31-Days-of-iOS--Day-10–Singletons-and-the-AppDelegate

#import "StopListSingleton.h"

NSArray *stopList;  // holds the list of stops

@implementation StopListSingleton

static StopListSingleton *singletonInstance;    /// used to hold class instance

+(StopListSingleton*) getInstance {

    NSLog(@"in getInstance");
    
    
    if (singletonInstance == nil) {
        singletonInstance = [[super alloc] init];  // create the class
        
        NSError *error;
        NSData *data = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"stops" ofType:@"json"]];
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
        
        stopList = json[@"stops"];
        NSSortDescriptor *sort = [NSSortDescriptor sortDescriptorWithKey:@"name" ascending:YES];
        stopList  = [stopList sortedArrayUsingDescriptors:@[sort]];
        
    }
    return singletonInstance;
}


-getList {
    return stopList;    // return the list of stops
}


@end
