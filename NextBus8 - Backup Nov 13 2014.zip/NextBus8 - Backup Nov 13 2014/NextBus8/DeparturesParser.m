//
//  DeparturesParser.m
//  NextBus8
//
//  Created by Mike K on 11/1/14.
//  Copyright (c) 2014 com.mkomadina. All rights reserved.
//
//  Used to read through the XML to extract bus departure information

#import "DeparturesParser.h"
#import "Bus.h"

@implementation DeparturesParser


-(id) initWithData: (NSMutableData *) readData {
    
    // NSXMLParser requires fixed NSData, so convert NSMutableData to NSData
    _data = [NSData dataWithData:readData];
    
    // initialize the bus array
    _busArray = [[NSMutableArray alloc] init];
    
    return self;
}

-(void) parseAPI {
    
    // start grouping buses by route and direction
    // increment the group number when a new route direction is found
    _groupNumber = 0;
    
    _parser = [[NSXMLParser alloc] initWithData:_data];
    _parser.delegate = self;
    [_parser parse];
    
}

- (void)parser:(NSXMLParser *)parser
didStartElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI
 qualifiedName:(NSString *)qName
    attributes:(NSDictionary *)attributeDict {
    
    // NSXMLparser calls "didStartElement" whenever it encounters a new XML element.
    // The method then has to determine if the element found is of interest
    
    // check if the elementName is relevant
    // if it matches, read the appropriate value or attribute
    
        
    if ( [elementName isEqualToString:@"RouteDirection"]) { // indicates bus direction
        
        NSString *thisDirection = [attributeDict objectForKey:@"Code"]; // direction Code
        
        if (thisDirection) {
            self.currentDirection = thisDirection;

            NSLog(@"Direction is %@", thisDirection);
        }
    }
    else if ( [elementName isEqualToString:@"Route"]) {
        
        NSString *thisRoute = [attributeDict objectForKey:@"Name"];     // route name
        
        if (thisRoute) {
            self.currentRoute = thisRoute;
            NSLog(@"Route is %@", thisRoute);
        }
    }
    else if ( [elementName isEqualToString:@"Stop"]) {
        
        NSString *thisStop = [attributeDict objectForKey:@"name"];      // stop name
        
        NSString *thisStopCode = [attributeDict objectForKey:@"StopCode"]; // stop code
        
        if (thisStop) {
            self.currentStopName = thisStop;
            NSLog(@"Stop is %@", thisStop);
            
        }
        
        if (thisStopCode) {
            self.currentStopCode = thisStopCode;
            NSLog(@"Stop code is %@", thisStopCode);
        }
        
    }
    else if ( [elementName isEqualToString:@"Agency"]) {
        
        
        NSString *thisAgencyName = [attributeDict objectForKey:@"Name"];    // agency name
        
        if (thisAgencyName) {
            self.currentAgency = thisAgencyName;
            NSLog(@"Agency is %@", thisAgencyName);
        }
        
    }
    else if ( [elementName isEqualToString:@"DepartureTimeList"]) {
        
        // increment the group number whenever there is a new DepartureTimeList which
        // occurs for each route/direction
        ++_groupNumber;
    }

    
    
    self.element = elementName;     // required by NSXMLParser to return element
}


// used to read bus times
// currently put in didEndElement to read after detecting the <DepartureTime> element
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
    
    if([self.element isEqualToString:@"DepartureTime"]) {
        
        Bus *thisBus = [[Bus alloc]
                        initWithTime:self.currentTimeToStop
                        forAgency:self.currentAgency
                        andRouteCode:self.currentRoute
                        andDirection:self.currentDirection
                        andStopName:self.currentStopName
                        andStopCode:self.currentStopCode
                        andGroupNumber:self.groupNumber
                        andSelected:FALSE];
        
        NSError *error;
        [_busArray addObject:thisBus];   // add the bus to the array
        
        NSLog(@"The next bus leaves in %@ minutes", self.currentTimeToStop);
        
    }

    
    
    self.element = nil;
}

// whenever DepartureTime is found, set the current time
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
    
    if ([self.element isEqualToString:@"DepartureTime"]) {
        self.currentTimeToStop = string;
        
    }
}


@end
