//
//  DeparturesViewController.h
//  NextBus8
//
//  Created by Mike K on 11/1/14.
//  Copyright (c) 2014 com.mkomadina. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DeparturesParser.h"
#import "RouteColor.h"

@interface DeparturesViewController : UIViewController <NSURLConnectionDelegate, UITableViewDataSource, UITableViewDelegate>

{
    
    IBOutlet UITableView *departureTableView;
    
    IBOutlet UILabel *MinutesLabel;
    
    IBOutlet UILabel *stopLabel;
    
    NSMutableData *_responseData;           // used for collecting API response data
    NSURLConnection *_connection;    // API connection object
    DeparturesParser *_departureParser;            // Parser to read through the XML
    
    NSMutableArray *_busArray;       // list of buses for a particular stop
    
    RouteColor *_routeColor;         // used to determine distinct colors for a route
    
    NSString *_sortBy;              // determines the sort order either by time or route

    
}

@property NSString *busStopCode;  // specifies what bus stop is being displayed

- (IBAction)buttonBusStops:(id)sender;

- (IBAction)directionButton:(id)sender;

- (IBAction)minutesButton:(id)sender;

-(void) fetchDepartures;            // get bus departures from the API
-(NSString *) getAPIURL;            // setup the URL for the API
-(void) parseResponse;              // parse the XML from the API call

@end
