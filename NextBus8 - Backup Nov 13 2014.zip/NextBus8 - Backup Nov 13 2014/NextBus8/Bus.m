//
//  Bus.m
//  NextBus8
//
//  Created by Mike K on 11/1/14.
//  Copyright (c) 2014 com.mkomadina. All rights reserved.
//

#import "Bus.h"

#define SECONDS_PER_MINUTE  60

@implementation Bus

// set bus departure information

-(id) initWithTime: (NSString *) departTime
         forAgency: (NSString *) agency
      andRouteCode: (NSString *) routeCode
      andDirection: (NSString *) direction
       andStopName: (NSString *) stopName
       andStopCode: (NSString *) stopCode
    andGroupNumber: (long) groupNumber
       andSelected: (BOOL) selectedBus
{
    
    self = [super init];
    
    // store the input parameters in the object
    
    if (self) {
        self.departMinutesXML = departTime;
        self.agencyXML = agency;
        self.routeCodeXML = routeCode;
        self.directionXML = direction;
        self.stopNameXML = stopName;
        self.stopCodeXML = stopCode;
        self.busGroupNumber = groupNumber;
    }
    
    return self;
    
}

-(long) departureMinutes
{
    // convert the XML string time to long
    long departMinutes = [_departMinutesXML integerValue];
    return departMinutes;
    
}

-(NSDate *) departureTime
{
    // convert the XML string to a date by calculating based on current time
    
    NSDate *currentDate = [NSDate date];
    long time = [self departureMinutes];
    return [currentDate dateByAddingTimeInterval:time * SECONDS_PER_MINUTE];
}

@end
