//
//  DeparturesParser.h
//  NextBus8
//
//  Created by Mike K on 11/1/14.
//  Copyright (c) 2014 com.mkomadina. All rights reserved.
//
//  The following video was helpful in understanding how to use NSXMLParser
//      https://www.youtube.com/watch?v=j2ocsvrenuw

#import <Foundation/Foundation.h>

@interface DeparturesParser : NSObject <NSXMLParserDelegate>

// Because of the XML structure, the parser has to read into it before getting to a specific
// bus.  The parsing needs to keep track of the context of the direction, stop, agency and route
// which are specified above the actual departure time

@property NSString *currentDirection;   // bus direction such as "EAST"
@property NSString *currentStopName;    // stop name such as "CANADA COLLEGE"
@property NSString *currentAgency;      // agency name such as "SAMTRANS"
@property NSString *currentRoute;       // bus route number such as "274"
@property NSString *currentTimeToStop;  // departure time in minutes
@property NSString *currentStopCode;    // stopcode retrieved from XML

@property NSMutableArray *busArray;      // main collection of Bus objects for the stop

@property NSString *element;            // used for reading each element
@property NSData *data;                 // hold the data

@property NSXMLParser *parser;          // parser object

@property long groupNumber;            // used to group buses with same route and direction


-(id) initWithData: (NSMutableData *) readData;    // setup the parser with the data
-(void) parseAPI;

@end
